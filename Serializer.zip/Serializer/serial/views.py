from django.shortcuts import render, redirect
from django.http import JsonResponse
from .serializers import *
from .models import *
# Create your views here.
import json
def display(request):
    serializer = JobSerializer(Job_details.objects.all(), many = True)
    serializer = json.dumps(serializer.data)
    serializer = json.loads(serializer)
    return render(request, "serial/index.html", {"serializer": serializer})

def add_job(request):
    try:
        company_name = request.POST.get('company_name')
        job_title = request.POST.get('job_title')
        package = request.POST.get('package')
        contact_email = request.POST.get('contact_email')
        if contact_email and company_name and job_title and package:
            job = Job_details(company_name = company_name, job_title = job_title, package = package, contact_email = contact_email)
            job.save()
            return redirect("/")
        raise Exception
    except Exception:   
        return render(request, "serial/add_job.html")