from django.db import models

# Create your models here.

class Job_details(models.Model):
    company_name = models.CharField(max_length = 100)
    job_title = models.CharField(max_length = 100)
    package = models.IntegerField()
    contact_email = models.EmailField()