from rest_framework import serializers

from .models import *

class JobSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job_details
        fields = '__all__'