from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def response(request):
    try:
        length = request.POST.get('length')
        width = request.POST.get('width')
        area = int(length) * int(width)
        return HttpResponse("<center><h1>The area of Rectangle is " + str(area) + "</h1></center>")
    except Exception:
        return HttpResponse("<center><h1>Failed</h1></center>")