from django.http import HttpResponse
from django.shortcuts import redirect, render
from .models import *
from django.contrib.auth import authenticate, login, logout 
from django.contrib.auth.decorators import login_required 
from django.contrib import messages
from django.contrib.auth.models import User
# Create your views here.

def signup(request):
    error_message = None
    if request.user.is_authenticated:
        logout(request)
    try:
        email = request.POST.get('email')
        password = request.POST.get('password')
        if email and password and len(email) > 0 and len(password) > 0:
            length = len(User_profile.objects.filter(email = email))
            if length > 0:
                error_message = "Email Id Already Exist"
                raise Exception
            user = User_profile(email = email, password = password)
            user.save()
            
            user = User.objects.create_user(username = email, email=email, password = password)
            user.save()
            return redirect("/signin")
        else:
            raise Exception
    except Exception:
        return render(request, "Signup.html", {'error_message' : error_message})

def signin(request):
    error_message = None
    if request.user.is_authenticated:
        return redirect('/dashboard')
    try:
        email = request.POST.get('email')
        password = request.POST.get('password')
        if len(email) > 0 and len(password) > 0:
            user = User_profile.objects.get(email = email, password = password)
            user = authenticate(username = email, password = password)
            error_message = "Invalid Email or Password"
            if user is not None:
                login(request, user)
                return render(request, "Home.html")
            else:
                error_message = "User is None"
            messages.error(request, 'Username or password does not exist')
            return render(request, "Signin.html", {"error_message" : error_message})
        else:
            error_message = "Please Enter the Details"
            raise Exception
    except Exception:
        return render(request, "Signin.html", {'error_message' : error_message})

@login_required(login_url='signin')
def dashboard(request):
    return render(request, "Home.html")

@login_required(login_url='signin')
def pricing(request):
    return render(request, "Pricing.html")

@login_required(login_url='signin')
def features(request):
    return render(request, "Features.html")