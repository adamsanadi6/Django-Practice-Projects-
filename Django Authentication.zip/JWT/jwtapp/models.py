from django.db import models
from mongoengine import Document, fields
# Create your models here.

class User_profile(models.Model):
    email = models.CharField(max_length=100, primary_key=True)
    password = models.CharField(max_length=100)

    def to_json(self):
        return {
            'email' : self.email,
            'password' : self.password
        }